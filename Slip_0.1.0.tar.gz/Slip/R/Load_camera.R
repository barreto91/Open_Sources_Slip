#' Loading a spectral camera.
#'
#' @param Camera_Name Name of camera to load.
#' @return Camera characteristics.
#' @export
Load_camera <- function(Camera_Name){
  githubURL <- paste("https://github.com/barreto91/Open_Sources_Slip/raw/master/Cameras/", Camera_Name, ".RData?raw=True", sep="")
  #load(url(githubURL))
  myfiles = eval(parse(text =load(url(githubURL))))
  rm(Camera)
  return(myfiles)
}

#Camera <-Load_camera("Rededge-M")

