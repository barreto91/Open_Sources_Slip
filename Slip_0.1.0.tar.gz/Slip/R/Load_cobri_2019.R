#' Loading information of trial field 2019.
#'
#' @param Information_type Type of informartion to load.
#' @return trial information.
#' @export
Load_cobri2019 <- function(Information_type){
  githubURL <- paste("https://github.com/barreto91/Open_Sources_Slip/raw/master/Cobri_2019/", Information_type, ".RData?raw=True", sep="")
  #load(url(githubURL))
  myfiles = eval(parse(text =load(url(githubURL))))
  rm(MyData)
  return(myfiles)
}

#Indices <-Load_indices("Multispectral_indices")


