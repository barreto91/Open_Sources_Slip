#' Loading a spectral indices.
#'
#' @param Indices_type Name of camera to load.
#' @return Camera characteristics.
#' @export
Load_indices <- function(Indices_type){
  githubURL <- paste("https://github.com/barreto91/Open_Sources_Slip/raw/master/Indices/", Indices_type, ".RData?raw=True", sep="")
  #load(url(githubURL))
  myfiles = eval(parse(text =load(url(githubURL))))
  rm(Index_List)
  return(myfiles)
}

#Indices <-Load_indices("Multispectral_indices")


