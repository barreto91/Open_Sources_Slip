#' Loading a spectral indices.
#'
#' @param Indices_type Name of camera to load.
#' @return Camera characteristics.
#' @export
Load_indices <- function(Indices_type){
  githubURL <- paste("https://github.com/barreto91/Open_Sources_Slip/raw/master/Indices/", Camera_Name, ".RData?raw=True", sep="")
  #load(url(githubURL))
  myfiles = eval(parse(text =load(url(githubURL))))
  rm(Camera)
  return(myfiles)
}

#Indices <-Load_indices("Multispectral_indices")

