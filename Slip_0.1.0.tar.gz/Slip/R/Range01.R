#' Range values from 0 to 1
#'
#' @param x vector, matriy or array to range
#' @return ranged array
#' @export
range01 <- function(x){(x-min(x))/(max(x)-min(x))}

#Camera <-Load_camera("Rededge-M")

