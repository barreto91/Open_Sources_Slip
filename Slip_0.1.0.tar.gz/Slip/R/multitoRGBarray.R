#' Multispectral to RGB array
#'
#' @param R Matrix of Red band
#' @param G Matrix of green band
#' @param B Matrix of blue band
#' @param nc number of columns of matrix
#' @param nr number of rows of matrix
#' @return RGB array with values from 0 to 1
#' @export
multitoRGBarray <- function(R, G, B,nc, nr){

  Im_RGB = array(0,dim=c(nr,nc,3))
  Im_RGB[,,1] = as.matrix(R)
  Im_RGB[,,2] = as.matrix(G)
  Im_RGB[,,3] = as.matrix(B)
  Im_RGB[is.na(Im_RGB)] <- 0
  max_V<-max(Im_RGB)
  Im_RGB = Im_RGB/max_V
  return(Im_RGB)

}

#Indices <-Load_indices("Multispectral_indices")

