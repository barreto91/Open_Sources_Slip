#' saving and plotting from RGB array (0 to 1)
#'
#' @param RGBarray rgb array with values from
#' @param Directory Directory to save image
#' @param Name Name to save image
#' @return RGB image on the mentioned directory
#' @export
plotandsaveRGB <- function(RGBarray, Directory, Name){

  Col_Mat<- rgb(RGBarray[,,1],RGBarray[,,2],RGBarray[,,3])
  nr= length(Im_RGB[1,,1])
  nc= length(Im_RGB[,1,1])
  Col_Mat <- matrix(Col_Mat ,ncol=nc,nrow=nr)
  Pixel_mat <- matrix( c(1:(nr*nc)), nrow=nr,ncol=nc)
  Transition_d <- getwd()
  setwd(Directory)

  par(mfcol=c(1,1),mar=c(0, 0, 0, 0))

  image(Pixel_mat, col=Col_Mat,axes = FALSE, useRaster=F)
  dev.copy(png,paste(Name, ".png",sep=""),height = nc,width = nr);dev.off()

  setwd(Transition_d)

  dev.off()

}
